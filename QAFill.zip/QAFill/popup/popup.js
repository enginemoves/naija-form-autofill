document.getElementById("fill-btn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["autofill.js"]
  });
});

document.getElementById("toggle-float").addEventListener("change", async (e) => {
  if (chrome?.storage?.sync) {
    await chrome.storage.sync.set({ floatingEnabled: e.target.checked });
  }
});

// Load toggle state on popup open safely
if (chrome?.storage?.sync) {
  chrome.storage.sync.get("floatingEnabled", (data) => {
    document.getElementById("toggle-float").checked = data?.floatingEnabled || false;
  });
}

document.getElementById("clear-btn").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const elements = document.querySelectorAll("input, textarea, select");
      elements.forEach(el => {
        if (el.type === "checkbox" || el.type === "radio") {
          el.checked = false;
        } else if (el.tagName.toLowerCase() === "select") {
          el.selectedIndex = 0;
        } else {
          el.value = "";
        }
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      });
    }
  });
});
