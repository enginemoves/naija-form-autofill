// Content script
console.log("Nigerian Autofill content script loaded.");

// Load floating button if enabled
chrome.storage.sync.get("floatingEnabled", (data) => {
  if (data.floatingEnabled) {
    injectFloatingButton();
  }
});

// Inject floating button function
function injectFloatingButton() {
  if (document.getElementById("na-floating-btn")) return;

  const btn = document.createElement("button");
  btn.id = "na-floating-btn";
  btn.textContent = "Autofill";

  Object.assign(btn.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    padding: "10px 15px",
    background: "#007bff",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    cursor: "grab",
    zIndex: 9999,
    boxShadow: "0 2px 6px rgba(0,0,0,0.3)"
  });

  // Make it draggable
  btn.onmousedown = function (event) {
    event.preventDefault();
    document.body.style.userSelect = "none";

    let shiftX = event.clientX - btn.getBoundingClientRect().left;
    let shiftY = event.clientY - btn.getBoundingClientRect().top;

    function moveAt(pageX, pageY) {
      btn.style.left = pageX - shiftX + 'px';
      btn.style.top = pageY - shiftY + 'px';
      btn.style.right = 'unset'; // prevent conflict with fixed 'right'
      btn.style.bottom = 'unset';
    }

    function onMouseMove(event) {
      moveAt(event.pageX, event.pageY);
    }

    document.addEventListener('mousemove', onMouseMove);

    btn.onmouseup = function () {
      document.removeEventListener('mousemove', onMouseMove);
      btn.onmouseup = null;
      document.body.style.userSelect = "auto";
    };
  };

  btn.ondragstart = function () {
    return false;
  };

  btn.addEventListener("click", () => {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("autofill.js");
    document.body.appendChild(script);
    script.onload = () => script.remove();
  });

  document.body.appendChild(btn);
}

// ✅ Watch for storage change to toggle floating button instantly
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync" && changes.floatingEnabled) {
    const isEnabled = changes.floatingEnabled.newValue;

    if (isEnabled) {
      injectFloatingButton();
    } else {
      const btn = document.getElementById("na-floating-btn");
      if (btn) btn.remove();
    }
  }
});
