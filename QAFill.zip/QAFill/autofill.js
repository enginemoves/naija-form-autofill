
console.log("Autofill running...");
// Nigerian Autofill Logic

console.log("Autofill running...");

(() => {
 

   const data = {
        names: [
            "Rita", "Anyanwu", "Segun", "Ikenna", "Peace", "Danjuma", "Tolu", "Onyeka", "John", "Okechukwu",
            "Chioma", "Garba", "Ifeanyi", "Obi", "Ngozi", "Abiola", "Kelechi", "Ahmed", "Adeola", "Adeyemi",
            "Blessing", "Omotola", "Yakubu", "Musa", "Ezekiel", "Okonkwo", "Zainab", "Iroko", "Adewale", "Etim",
            "Halima", "Lawal", "Nnamdi", "Chukwuma", "Tope", "Akinyemi", "Chinwe", "Fatima", "Gbenga", "Mohammed",
            "Mary", "Ikenna", "Emeka", "Salami", "Obinna", "Nwosu", "James", "Eze", "Adamu", "Okafor",
            "Samuel", "Patience", "Abdul", "Jide", "Yusuf", "Favour", "Glory", "Amina", "Joseph", "Oluwaseun",
            "Esther", "Philip", "David", "Funke", "Suleiman", "Hope", "Hauwa", "Opeyemi", "Dolapo", "Olamide",
            "Ada", "Juliet", "Abdullahi", "Kemi", "Bukola", "Deborah", "Chuka", "Kelvin", "Gbemi", "Amaka",
            "Ibrahim", "Osas", "Temitope", "Chisom", "Aisha", "Kunle", "Precious", "Nkechi", "Uche", "Ebuka",
            "Lilian", "Ajayi", "Titi", "Chigozie", "Malik", "Funmilayo", "Queen", "Abubakar", "Chidimma", "Sunday",
            "Odion", "Olawale", "Ireti", "Eniola", "Ayoola", "Rukayat", "Olabisi", "Chinyere", "Femi", "Hope",
            "Paul", "Danladi", "Nura", "Joy", "Gabriel", "Titus", "Anthonia", "Nosa", "Raphael", "Ajoke",
            "Tosin", "Taiwo", "Kafayat", "Azeez", "Temidayo", "Ismail", "Zubairu", "Ijeoma", "Yewande", "Florence",
            "Rasaq", "Abimbola", "Shola", "Bidemi", "Dorcas", "Kehinde", "Yahaya", "Oladimeji", "Umar", "Chisom",
            "Ayodele", "Adesuwa", "Chidera", "Lukman", "Hadiza", "Awele", "Ejike", "Bashir", "Kudirat", "Somto",
            "Bello", "Ndubuisi", "Olumide", "Mariam", "Oche", "Rafiu", "Onyinye", "Bolaji", "Mustapha", "Bosede",
            "Sola", "Lateef", "Gideon", "Uduak", "Doris", "Onome", "Ejiro", "Anita", "Folake", "Peter",
            "Ngozika", "Ishaq", "Jumoke", "Chuks", "Titilayo", "Idris", "Eunice", "Ozioma", "Dare", "Raymond",
            "Benedict", "Sanni", "Ikem", "Yetunde", "Tajudeen", "Bisi", "Ifeoma", "Adekunle", "Olaide", "Chuka",
            "Ovie", "Victoria", "Sulaimon", "Omowumi", "Promise", "Ebun", "Haliru", "Emmanuel", "Farida", "Ugochi",
            "Tofunmi", "Nathaniel", "Comfort", "Peace", "Tamar", "Aremu", "Blessing", "Jamilu", "Simeon", "Chukwudi",
            "Mercy", "Ganiyu", "Jasper", "Umaru", "Nwachukwu", "Ikram", "Zainabu", "Chinonso", "Adesina", "Munirat"
        ],
        addresses: [
            "23 Allen Avenue, Ikeja", "17 Ahmadu Bello Way, Kaduna", "5 Gwarinpa Estate, Abuja", "12 Oba Akran Avenue, Lagos", "31 Nnamdi Azikiwe Street, Enugu",
            "8 Okpara Avenue, Enugu", "50 Airport Road, Benin City", "14 Ogui Road, Enugu", "72 Awolowo Road, Ikoyi", "66 Adeola Odeku Street, Victoria Island",
            "34 Obafemi Awolowo Way, Ikeja", "9 Tafawa Balewa Crescent, Lagos Island", "19 Ekukinam Street, Utako", "10 Bida Road, Onitsha", "87 Oke Ilewo Road, Abeokuta",
            "42 Nnebisi Road, Asaba", "28 Wetheral Road, Owerri", "39 Bank Road, Kano", "61 Stadium Road, Port Harcourt", "45 Herbert Macaulay Road, Yaba",
            "32 Gana Street, Maitama", "16 Olusegun Obasanjo Way, Abuja", "77 Bompai Road, Kano", "11 New Market Road, Onitsha", "3 Ebitu Ukiwe Street, Jabi",
            "22 IBB Way, Calabar", "68 Presidential Road, Enugu", "47 Old Market Road, Uyo", "18 Ajose Adeogun Street, VI", "25 New Haven Avenue, Enugu",
            "4 Constitution Road, Kaduna", "51 Okigwe Road, Owerri", "36 Ahmadu Bello Way, Bauchi", "6 Secretariat Road, Minna", "20 Sapele Road, Benin City",
            "8 Ring Road, Ibadan", "55 Birnin Kebbi Road, Sokoto", "30 Effurun-Sapele Road, Warri", "43 Umuahia Road, Aba", "15 Chief Nwuke Street, Port Harcourt",
            "7 Asa Road, Aba", "60 Race Course Road, GRA Kano", "12 Lagos Street, Jos", "40 Iyowuna Drive, Trans Amadi", "3 Oke-Ado Road, Ibadan",
            "26 Akenzua Street, Benin", "35 Uselu-Lagos Road, Benin", "9 Samonda Road, Ibadan", "48 Akpakpava Street, Benin", "5 Oron Road, Uyo",
            "13 Nsukka Road, Onitsha", "57 Liman Road, Gombe", "44 Jos Road, Lafia", "70 Ali Akilu Road, Kaduna", "2 Hospital Road, Ado-Ekiti",
            "19 Gidan Waya Road, Kafanchan", "76 Benin-Sapele Road, Benin", "11 Otigba Street, Ikeja", "37 Airport Bypass, Ilorin", "22 Aba Road, PH",
            "6 Garden Avenue, Enugu", "80 Mohammed Buhari Way, Katsina", "27 Eastern Bypass, Owerri", "24 Ijebu Ode Road, Ijebu-Ode", "65 Ota Road, Ota",
            "90 Ogba Road, Ikeja", "17 Ede Road, Osogbo", "13 Iseyin Road, Ibadan", "39 Okpanam Road, Asaba", "5 Ajegunle Road, Apapa",
            "50 Uselu Road, Benin", "29 Gwagwalada Road, Abuja", "41 Ikot Ekpene Road, Uyo", "23 Bida Road, Minna", "10 Ajaokuta Road, Lokoja",
            "44 Bauchi Road, Jos", "18 Garki Road, Kaduna", "75 Sabo Gari Road, Kano", "14 Okene Road, Lokoja", "81 Ore-Benin Road, Ore",
            "32 Eket Road, Uyo", "63 Uyo Road, Ikot Ekpene", "8 Kubwa Expressway, Abuja", "19 Benin Road, Akure", "12 Owerri Road, Umuahia",
            "48 Shagamu Road, Ikorodu", "25 Challenge Road, Ibadan", "59 Ogbomosho Road, Ogbomosho", "7 Ife Road, Ile-Ife", "34 Mubi Road, Yola",
            "26 Jalingo Road, Jalingo", "88 Nnewi Road, Nnewi", "9 Yenagoa Road, Yenagoa", "20 Aba Owerri Road, Aba", "42 Lokoja-Abuja Expressway, Kogi",
            "11 Sapele-Warri Road, Sapele", "53 Eleyele Road, Ibadan", "33 Oluyole Road, Ibadan", "18 Zaria Road, Jos", "77 Jikwoyi Road, Abuja",
            "3 Oniru Road, VI", "60 Ijoko Road, Ogun", "24 Owode Road, Ogun", "29 Osogbo-Ilesha Road, Osogbo", "38 Apata Road, Ibadan",
            "44 Ojota Road, Lagos", "55 Shomolu Road, Lagos", "70 Epe Road, Epe", "13 Ikotun Road, Alimosho", "15 Ogudu Road, Lagos",
            "21 Amuwo Odofin Road, Mile 2", "5 Badagry Expressway, Lagos", "61 Egbeda Road, Egbeda", "72 Bariga Road, Bariga", "36 Festac Road, Festac",
            "90 Lekki-Epe Expressway, Lekki", "17 Chevron Drive, Lekki", "11 Admiralty Way, Lekki", "23 Victoria Garden City, Lekki", "10 Alpha Beach Road, Lekki",
            "4 Abacha Road, GRA Port Harcourt", "14 Emenike Street, Port Harcourt", "33 Tombia Street, Port Harcourt", "58 Rumuola Road, Port Harcourt", "19 Choba Road, PH",
            "7 GRA Phase 2, Benin", "31 Upper Mission Road, Benin", "6 Sapele Road, Benin", "45 Iyaro Road, Benin", "22 Akure-Ilesha Road, Akure",
            "10 Oba Adesida Road, Akure", "27 Owo Road, Akure", "3 Ikare Road, Ondo", "13 Alagbaka Road, Akure", "25 Alagbaka GRA, Akure",
            "41 Ojoo-Iwo Road, Ibadan", "54 Ring Road, Ibadan", "16 Olomi Road, Ibadan", "67 Oke Ado Road, Ibadan", "85 Bodija Market Road, Ibadan",
            "37 Dugbe Road, Ibadan", "71 Challenge-Ring Road, Ibadan", "39 Felele Road, Ibadan", "43 Mokola Hill Road, Ibadan", "9 Agodi Gate Road, Ibadan",
            "48 Adegbite Street, Ibadan", "60 Ayobo Road, Ipaja", "88 Ogundele Street, Egbeda", "34 Alimosho Road, Lagos", "22 Ipaja Road, Agege",
            "12 Ojodu Berger Road, Ikeja", "17 Isheri Road, Ojodu", "51 Agidingbi Road, Ikeja", "66 Ogba-Ijaiye Road, Lagos", "29 Otunba Jobifele Way, Ikeja",
            "77 Toyin Street, Ikeja", "19 Awolowo Road, Bodija", "10 Secretariat Road, Osogbo", "43 Igbara Road, Ondo", "84 Ijebu-Ode Road, Ijebu",
            "23 Zaria-Gusau Road, Zamfara", "52 Sokoto Road, Sokoto", "64 Bauchi-Jos Road, Bauchi", "35 Gusau-Funtua Road, Zamfara", "11 Katsina Road, Katsina",
            "16 Gombe-Dutse Road, Gombe", "28 Dutse-Birnin Kudu Road, Jigawa", "33 Azare Road, Bauchi", "72 Ringim Road, Jigawa", "48 Potiskum Road, Yobe",
            "5 Damaturu Road, Yobe", "26 Maiduguri-Bama Road, Borno", "44 Jalingo-Wukari Road, Taraba", "57 Makurdi-Otukpo Road, Benue", "30 Otukpo Road, Benue",
            "9 Gboko Road, Benue", "38 Gboko-Makurdi Road, Benue", "40 Lokoja-Ajaokuta Road, Kogi", "13 Kabba Road, Lokoja", "18 Okene-Auchi Road, Edo",
            "24 Auchi-Aviele Road, Edo", "55 Uromi Road, Edo", "21 Irrua Road, Edo", "31 Afuze Road, Edo", "43 Ehor Road, Edo",
            "6 Isanlu Road, Kogi", "12 Obajana Road, Kogi", "7 Okpella Road, Edo", "10 Osogbo-Ikirun Road, Osun", "59 Ijebu Ode-Epe Road, Ogun",
            "8 Akute Road, Ogun", "20 Agbara-Atan Road, Ogun", "50 Ewekoro Road, Ogun", "36 Papalanto Road, Ogun", "63 Shagamu-Ikorodu Road, Ogun"
        ],
        emailDomains: ["yopmail.com", "mailinator.com"],
        phonePrefixes: ["080", "081", "090", "070"],
        genders: ["Male", "Female"],
        titles: ["Mr", "Mrs", "Miss", "Dr"],
        states: [
            "Lagos", "Abuja", "Kano", "Enugu", "Oyo",
            "Rivers", "Kaduna", "Anambra", "Delta", "Edo",
            "Ogun", "Plateau", "Cross River", "Benue", "Sokoto"
        ],
        lgas: [
            "Ikorodu", "Alimosho", "Surulere", "Eti-Osa", "Ikeja",
            "Nsukka", "Enugu North", "Onitsha South", "Awka South", "Nnewi North",
            "Gwagwalada", "Bwari", "Abaji", "Karu", "Kuje",
            "Sabon Gari", "Zaria", "Jos North", "Yola South", "Ado Ekiti"
        ],
        cities: [
            "Ikeja", "Ikorodu", "Obalende", "Surulere", "Ajah", "Festac", "Lekki", "Yaba", "Agege", "Ogba",
            "Gwarinpa", "Maitama", "Wuse", "Utako", "Mararaba", "Kubwa", "Zuba", "Karimo", "Ojota", "Ojodu",
            "Oshodi", "Apapa", "Badagry", "Egbeda", "Iyana Ipaja", "Sango Ota", "Alausa", "Abeokuta South", "Abeokuta North", "Challenge",
            "Dugbe", "Bodija", "Ring Road", "New Haven", "Abakpa", "Trans Amadi", "Rumuokoro", "D-Line", "Nnewi", "Nsukka"
        ]

    };

  function getRandomItem(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function getRandomNameParts() {
    const index = Math.floor(Math.random() * (data.names.length / 2)) * 2;
    const firstName = data.names[index];
    const lastName = data.names[index + 1];
    return {
      full: `${firstName} ${lastName}`,
      firstName,
      lastName
    };
  }

  function getRandomUsername(first, last) {
    return `${first.toLowerCase()}${last.toLowerCase()}${Math.floor(Math.random() * 1000)}`;
  }

  function getRandomEmail(name) {
    const domain = getRandomItem(data.emailDomains);
    const clean = name.toLowerCase().replace(/\s+/g, ".");
    const num = Math.floor(Math.random() * 1000);
    return `${clean}${num}@${domain}`;
  }

  function getRandomPhone() {
    const prefix = getRandomItem(data.phonePrefixes);
    const suffix = Math.floor(10000000 + Math.random() * 90000000);
    return `${prefix}${suffix}`;
  }

  function getRandomDOB() {
    const year = Math.floor(Math.random() * (2005 - 1970 + 1)) + 1970;
    const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
    const day = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function getBVN() {
    return "22" + Math.floor(100000000 + Math.random() * 900000000);
  }

  function getNIN() {
    return "20" + Math.floor(100000000 + Math.random() * 900000000);
  }

  function getFieldType(attrValue) {
    const val = attrValue.toLowerCase();
    const map = [
      { type: "first", keywords: ["first", "firstname"] },
      { type: "last", keywords: ["last", "surname"] },
      { type: "middle", keywords: ["middle"] },
      { type: "email", keywords: ["email"] },
      { type: "phone", keywords: ["phone", "mobile"] },
      { type: "bvn", keywords: ["bvn"] },
      { type: "nin", keywords: ["nin"] },
      { type: "address", keywords: ["address"] },
      { type: "city", keywords: ["city", "town"] },
      { type: "zip", keywords: ["zip", "postal"] },
      { type: "lga", keywords: ["lga", "local"] },
      { type: "state", keywords: ["state"] },
      { type: "country", keywords: ["country"] },
      { type: "username", keywords: ["username", "user_name", "handle", "accountname"] },
      { type: "gender", keywords: ["gender"] },
      { type: "title", keywords: ["title"] },
      { type: "dob", keywords: ["birth", "dob"] },
      { type: "name", keywords: ["name"] },
    ];
    for (const { type, keywords } of map) {
      if (keywords.some(k => val.includes(k))) return type;
    }
    return null;
  }

  const fields = document.querySelectorAll("input, select, textarea");
  const { full, firstName, lastName } = getRandomNameParts();
  const username = getRandomUsername(firstName, lastName);

  fields.forEach(field => {
    const attrs = [
      field.name,
      field.id,
      field.placeholder,
      field.getAttribute("aria-label"),
      field.getAttribute("autocomplete")
    ].filter(Boolean).join(" ");
    const type = getFieldType(attrs);

    if (field.tagName.toLowerCase() === "select") {
      let value;
      if (type === "gender") value = getRandomItem(data.genders);
      else if (type === "title") value = getRandomItem(data.titles);
      else if (type === "state") value = getRandomItem(data.states);
      else if (type === "lga") value = getRandomItem(data.lgas);
      else if (type === "country") value = "Nigeria";

      if (value) {
        [...field.options].forEach(opt => {
          if (
            opt.value.toLowerCase() === value.toLowerCase() ||
            opt.text.toLowerCase() === value.toLowerCase()
          ) {
            opt.selected = true;
            field.dispatchEvent(new Event("change", { bubbles: true }));
          }
        });
      }
      return;
    }

    let value;
    switch (type) {
      case "first": value = firstName; break;
      case "last": value = lastName; break;
      case "middle": value = getRandomItem(data.names); break;
      case "name": value = full; break;
      case "email": value = getRandomEmail(full); break;
      case "phone": value = getRandomPhone(); break;
      case "address": value = getRandomItem(data.addresses); break;
      case "city": value = getRandomItem(data.cities); break;
      case "zip": value = String(Math.floor(1 + Math.random() * 9999)).padStart(4, '0'); break;
      case "bvn": value = getBVN(); break;
      case "nin": value = getNIN(); break;
      case "username": value = username; break;
      case "country": value = "Nigeria"; break;
      case "state": value = getRandomItem(data.states); break;
      case "lga": value = getRandomItem(data.lgas); break;
      case "dob": value = getRandomDOB(); break;
    }

    if (value !== undefined) {
      field.value = value;
      field.dispatchEvent(new Event("input", { bubbles: true }));
    }
  });
})();
